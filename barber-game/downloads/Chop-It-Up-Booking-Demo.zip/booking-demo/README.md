# Chop It Up — Customer Booking Demo

Developer handoff of https://www.johnrice.com/barber-game/customer-v2/
Downloaded October 6, 2026.

## Run locally

Unzip, open a terminal in this `booking-demo` folder, and run:

```sh
python3 -m http.server 8000
```

On Windows, `py -m http.server 8000` is an alternative. Open http://localhost:8000/ in your browser. Any static web server works; serve this folder as the web root. Do not open the HTML with a file:// URL: the original root-relative asset paths require an HTTP server.

No build, npm installation, API keys, or database is required. The entry point is `barber-game/customer-v2/index.html`; application CSS and JavaScript are inline there. Shared presentation CSS and all referenced image assets are included in their original directory structure. Fonts are system fonts and icons are inline SVG/text.

## Scope

Includes the desktop presentation shell, mobile booking interface, shop discovery, barber directory/profiles, services, availability, booking confirmation, sample account/profile flows, and optional loading-screen preview (`/barber-game/customer-v2/?splash=1`).

This is a frontend prototype, not a production booking system. Availability, prices, placement, ranks, and other fixtures are illustrative. Booking confirmations do not reserve real appointments. Sign-in, recovery code, and CAPTCHA are demonstrations, not secure authentication. Sample account details may be retained in browser localStorage; use fictional information. There is no backend, payment processing, real account creation, or email/SMS delivery in this package.

## Packaging changes

- Removed the johnrice.com presentation session gate (`tbg-auth`) so the standalone demo opens without the surrounding website login. This does not change the demo's customer sign-in screens.
- Made the sidebar's “The Barbergame” link explicitly point to the original website, outside this package.
- Added a root launch page, this README, and a SHA-256 asset manifest.

The live website was not changed. Booking behavior and visual design are otherwise preserved.

## External links

Maps/directions, social links, team applications, email/telephone actions, and the link back to The Barbergame remain external. They are not dependencies for rendering or using the booking demo. Sharing uses the browser's share/clipboard APIs and may depend on browser permissions. The booking UI and images can run without internet after starting the local server.

## Implementation notes

Keep root-relative `/barber-game/...` paths when deploying, or update them if integrating under another base path. All application code is unminified and editable. `MANIFEST.sha256` lists included application asset checksums. Images remain subject to their existing ownership and usage rights; this handoff does not grant new third-party rights.
