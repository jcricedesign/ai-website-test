# Chop It Up — Customer v2 frontend assets

Asset handoff for https://www.johnrice.com/barber-game/customer-v2/.

## Contents

- 28 barber portraits: `barber-game/assets/*.jpg`.
- One supplied raster logo: `barber-game/chop-it-up/ChopItUp-Logo.png`.
- Three supplied haircut images: `barber-game/chop-it-up/redesign/haircut-*.png` (included from the demo handoff; not directly referenced in customer-v2).
- Shared desktop presentation styles: `barber-game/assets/flow-viewer.css`.
- Complete runnable frontend reference: `barber-game/customer-v2/index.html`, including inline application CSS, JavaScript, icons, sample data, and mobile/desktop behavior.
- A root launch page and `ASSET-INVENTORY.csv` with paths, dimensions, sizes, and checksums.

## Run the reference

Serve this extracted folder as the web root:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000/. Windows can use `py -m http.server 8000`.
No package installation or build step is required. Use HTTP rather than opening the file directly.

## Dependency checklist

| Dependency | Included / implementation |
| --- | --- |
| Logo and all named barber portraits | Included at the original paths. |
| Customer interface CSS and JavaScript | Inline in the reference HTML; retain or move into the application bundle. |
| Shared presentation shell CSS | Included as `flow-viewer.css`. |
| Fonts | System font stack; no downloaded font files needed. |
| Icons | Inline SVG and text glyphs in the source; no icon package needed. |
| Frameworks, CDNs, npm dependencies | None required by this demo. |
| Audio files | No audio file dependency found in customer-v2. |
| Sample shops, services, prices, ranks, and availability | Inline fixtures; replace with backend data. |
| Account persistence | Browser localStorage demonstration; replace with production account handling. |
| Share and clipboard | Browser APIs; HTTPS and user interaction may be required. |
| Maps, social, application, email, and phone actions | External destinations; not downloaded assets. |

## Integration details

Paths beginning `/barber-game/` assume this folder is served at the domain root. Preserve that structure or update the asset base path during integration. Filenames are case-sensitive. `Adrian .jpg` and `Lana .jpg` contain a space before the extension; the reference URLs use `%20`. Keep the filenames or update their references together.

The reference removes only the surrounding johnrice.com presentation login gate and makes its back link absolute. Customer sign-in screens remain in place.

Bookings, phone/email verification, recovery codes, CAPTCHA, and account flows are demonstrations. The ZIP contains no production authentication, appointment reservation, payment processing, or SMS/email service. Availability, shop assignment, services, prices, and ranks are illustrative and need authoritative backend data.

Only the supplied PNG logo is present; vector artwork and alternate logo exports are not included. Photos retain their existing dimensions; this bundle does not upscale them. The unidentified `IMG_2156.jpg` is intentionally excluded in the source until a barber name is confirmed. Existing asset ownership and usage rights still apply.
